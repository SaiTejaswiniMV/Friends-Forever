<?php
extract($_GET);
$file=fopen("users.txt","r");
$arr=array();
$i=0;
$string="";
while($line=fgets($file))
{
	$l = trim(preg_replace('/\s\s+/', ' ', $line));
	$a=explode("=>",$l);
	if($a[0]=="Teju"){
			
			$c=$a[0].'=>'.$a[1].','.$friend."\n"; 
			$line=$c;
						
		}
		
	
	
	$arr[$i++]=$line;
		
			
}
$l="";
for($j=0;$j<sizeof($arr);$j++)
{
	echo $arr[$j];
	$l=$l.$arr[$j];
}
//echo $l;
$f=fopen("users.txt","wb");
fwrite($f,$l);
echo"Succesfully added";
?>
