<?php
extract($_GET);
$file=fopen("users.txt","r");
$arr=array();
$i=0;
$string="";
while($line=fgets($file))
{
	$l = trim(preg_replace('/\s\s+/', ' ', $line));
	$a=explode("=>",$l);
	if($a[0]==$friend){
					break;
				
		}
		
}
$j=0;
$b=explode(";",$a[1]);

for($i=0;$i<sizeof($b);$i++)
{
	$c=explode(":",$b[$i]);

	
			$d[$j]=$c[0];
			$e[$j]=$c[1];
			$j++;
		
	

}
$arr=array();
for($i=0;$i<sizeof($d);$i++)
{
	$arr[$d[$i]]=$e[$i];
	//echo $d[$i].":".$e[$i]."<br>";

}
echo json_encode($arr);
