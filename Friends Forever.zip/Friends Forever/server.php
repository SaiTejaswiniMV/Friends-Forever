<?php
	header("Content-type:text/event-stream");
	ob_start();
	extract($_GET);
	$x=$a.".txt";
	$y=$b.".txt";
	$oldtimeA=filemtime($x);
	$oldtimeB=filemtime($y);
	//$z=$a."_".$b.".txt";
	$updt=fopen("teju_vidya.txt","a");
	//$file=fopen($x,"a");
	//$chat=$ch;
	//fwrite($file,$chat);
	//fclose($file);
	
while(true)
{ 
		clearstatcache();
	$newtimeA=filemtime($x);
	$newtimeB=filemtime($y);
	
	echo "event:received\n";
		//Automatic retry occurs every 3 seconds. The line below changes it to 10 s.
		echo "retry:10000\n";
		//Last line must end with two \n 
		if($newtimeA>$oldtimeA){
		clearstatcache();
		$sendA=file_get_contents($x);
		$resA=explode("\n",$sendA);
		$rA=sizeof($resA)-1;
		echo "data:$a: $resA[$rA]\n\n";
		//$txt=data:<h2>A: $resA[$rA]</h2>\n\n;
		fwrite($updt,$a.":".$resA[$rA]."\n");
		//fclose($updt);
		ob_flush();
		flush();
		$oldtimeA=$newtimeA;
		
		}
		if($newtimeB>$oldtimeB){
		clearstatcache();
		$sendB=file_get_contents($y);
		$resB=explode("\n",$sendB);
		$rB=sizeof($resB)-1;
		echo "data:$b: $resB[$rB]\n\n";
		//$txt=data:<h2>A: $resA[$rA]</h2>\n\n;
		fwrite($updt,$b.":".$resB[$rB]."\n");
		//fclose($updt);
		ob_flush();
		flush();
		$oldtimeB=$newtimeB;
		
		}
		
		sleep(4);
}
?>