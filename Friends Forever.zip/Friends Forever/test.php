<?php
$file=fopen("test.txt","r");
$arr=array();
$i=0;
$string="";
//$lines = file('test.txt', FILE_IGNORE_NEW_LINES);
			// var_dump($lines);
while($line=fgets($file))
{
	//$x=trim($line,'\n');
	$l = trim(preg_replace('/\s\s+/', ' ', $line));
	$a=explode("=>",$l);
	if($a[0]=="Teju"){
			//$a[1]=$string;
		     //$string = str_replace(array("\r", "\n"), '', $string);
			 //$string=a[1];
			 
		    //$string = str_replace("\n", " ", $a[1]);
			//$x=trim($a[1]);
			$c=$a[0].':'.$a[1].',Hello people'; 
			$line=$c;
						
		}
		
	
	
	$arr[$i++]=$line;
		
			
}
$l="";
for($j=0;$j<sizeof($arr);$j++)
{
	echo $arr[$j];
	$l=$l.$arr[$j]."\n";
}
echo $l;
$f=fopen("test.txt","wb");
fwrite($f,$l);
?>
