<?php
extract($_GET);
 $file=fopen("teju.txt","a");
 $c=PHP_EOL.$ch;
 fwrite($file,$c);
 //fclose($file);
 echo "Success";

?>