<?php
extract($_GET);
$file=fopen("posts.txt","r");
$arr=array();
$i=0;
$string="";
while($line=fgets($file))
{
	$l = trim(preg_replace('/\s\s+/', ' ', $line));
	$a=explode("=>",$l);
	if($a[0]=="Teju"){
			
			$c=$a[0].'=>'.$a[1].';<p style="font-size:3em">'.$txt.'</p>'."\n"; 
			$line=$c;
						
		}
		
	
	
	$arr[$i++]=$line;
		
			
}
$l="";
for($j=0;$j<sizeof($arr);$j++)
{
	//echo $arr[$j];
	$l=$l.$arr[$j];
}
//echo $l;
$f=fopen("posts.txt","wb");
fwrite($f,$l);
echo"Succesfully added";
?>
